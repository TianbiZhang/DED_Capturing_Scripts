#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
# Copyright (C) 2020 Daniel Turecek
#
# @file      main.py
# @author    Daniel Turecek <daniel@turecek.de>
# @date      2020-06-16
import pkg_resources
import pygui

uiString = (pkg_resources.resource_string(__name__, "form.ui")).decode()
window = pygui.loadFromUiString(uiString)
print(window)
